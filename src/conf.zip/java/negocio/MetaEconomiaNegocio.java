package negocio;

import java.sql.SQLException;
import model.MetaEconomia;
import persistencia.MetaEconomiaP;

public class MetaEconomiaNegocio {

    public void salvarMeta(MetaEconomia meta) throws Exception {
        if (meta.getDescricao() == null || meta.getDescricao().trim().isEmpty()) {
            throw new Exception("A descrição da meta não pode estar vazia.");
        }
        if (meta.getValorObjetivo() <= 0) {
            throw new Exception("O valor objetivo deve ser maior que zero.");
        }
        if (meta.getValorPoupado() < 0) {
            throw new Exception("O valor poupado não pode ser negativo.");
        }

        try {
            new MetaEconomiaP().salvar(meta);
        } catch (SQLException e) {
            e.printStackTrace(); 
            throw new Exception("Erro ao salvar a meta no banco: " + e.getMessage());
        }
    }
}