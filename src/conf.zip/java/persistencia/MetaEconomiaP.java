package persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import model.MetaEconomia;
import util.ConexaoDB;

public class MetaEconomiaP {

    public void salvar(MetaEconomia meta) throws SQLException {
        String sql = "INSERT INTO meta_economia "
                   + "(id_usuario, descricao, valorObjetivo, valorPoupado) VALUES (?, ?, ?, ?)";

        try (Connection con = ConexaoDB.conectar();
             PreparedStatement stm = con.prepareStatement(sql)) {

            stm.setInt(1, meta.getIdUsuario());
            stm.setString(2, meta.getDescricao());
            stm.setDouble(3, meta.getValorObjetivo());
            stm.setDouble(4, meta.getValorPoupado());

            stm.executeUpdate();
        }
    }
}