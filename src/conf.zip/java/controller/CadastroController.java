package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Usuario;
import negocio.UsuarioNegocio;

@WebServlet(name = "CadastroController", urlPatterns = {"/CadastroController"})
public class CadastroController extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
        try 
        {
            String nome = request.getParameter("nome").trim();
            String email = request.getParameter("email").trim();
            String senha = request.getParameter("senha");
            
            Usuario usuario = new Usuario();
            usuario.setNome(nome);
            usuario.setEmail(email);
            usuario.setSenha(senha);
            usuario.setQuantiaUsuario(0.0); 
            
            UsuarioNegocio negocio = new UsuarioNegocio();
            negocio.cadastrarUsuario(usuario);
            
            response.sendRedirect("login.jsp?sucesso=true");
        } 
        catch (Exception e) 
        {
            e.printStackTrace();
            request.setAttribute("erroRegisto", e.getMessage());
            request.getRequestDispatcher("cadastro.jsp").forward(request, response);
        }
    }
}