package controller;

import java.io.IOException;
import java.net.URLEncoder;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.MetaEconomia;
import model.Usuario;
import negocio.MetaEconomiaNegocio;

@WebServlet(name = "MetaController", urlPatterns = {"/MetaController"})
public class MetaController extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        HttpSession sessao = request.getSession();
        Usuario usuario = (Usuario) sessao.getAttribute("usuarioLogado");

        if (usuario == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        try {
            String descricao = request.getParameter("descricao");
            String objetivoStr = request.getParameter("valorObjetivo");
            String poupadoStr = request.getParameter("valorPoupado");

            if (descricao == null || objetivoStr == null || poupadoStr == null) {
                throw new Exception("Campos do formulário ausentes (confira os atributos name no JSP).");
            }

            double valorObjetivo = Double.parseDouble(objetivoStr.trim().replace(",", "."));
            double valorPoupado = Double.parseDouble(poupadoStr.trim().replace(",", "."));

            MetaEconomia meta = new MetaEconomia();
            meta.setIdUsuario(usuario.getId());
            meta.setDescricao(descricao.trim());
            meta.setValorObjetivo(valorObjetivo);
            meta.setValorPoupado(valorPoupado);

            MetaEconomiaNegocio negocio = new MetaEconomiaNegocio();
            negocio.salvarMeta(meta);

            response.sendRedirect("menu.jsp?sucesso=true");

        } catch (NumberFormatException e) {
            response.sendRedirect("menu.jsp?erro="
                    + URLEncoder.encode("Valores numéricos inválidos.", "UTF-8"));
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("menu.jsp?erro="
                    + URLEncoder.encode(String.valueOf(e.getMessage()), "UTF-8"));
        }
    }
}