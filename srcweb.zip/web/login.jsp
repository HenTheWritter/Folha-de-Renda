<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Login - Folha de Renda</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        body { background-color: #ffffff; }

        .navbar {
            background-color: #121212; 
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 30px;
            height: 70px;
            border-bottom: 4px solid #4CAF50;
        }
        .nav-logo { color: #4CAF50; font-size: 24px; font-weight: bold; letter-spacing: 2px; }
        .nav-links { display: flex; gap: 30px; }
        .nav-links a { color: #fff; text-decoration: none; font-size: 17px; font-weight: 300; transition: color 0.3s; }
        .nav-links a:hover { color: #4CAF50; }
        .nav-profile { color: #fff; font-size: 24px; cursor: pointer; }

        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: calc(100vh - 70px);
        }

        .form-box {
            background-color: #f9f9f9;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            width: 100%;
            max-width: 400px;
            border-top: 4px solid #4CAF50; /* Detalhe verde no topo da caixa */
        }
        .form-box h2 { color: #333; margin-bottom: 25px; font-size: 22px; text-align: center; }
        
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; color: #555; font-weight: bold; font-size: 14px; }
        .form-group input { width: 100%; padding: 12px; border: 1px solid #ccc; border-radius: 4px; font-size: 14px; }
        .form-group input:focus { outline: none; border-color: #4CAF50; }

        .btn-green { width: 100%; padding: 12px; border: none; border-radius: 4px; font-size: 16px; font-weight: bold; cursor: pointer; background-color: #4CAF50; color: white; transition: background 0.3s; margin-top: 10px; }
        .btn-green:hover { background-color: #388E3C; }

        .alert-error { background-color: #ffebee; color: #c62828; border: 1px solid #ef9a9a; padding: 12px; border-radius: 4px; margin-bottom: 20px; text-align: center; font-size: 14px; }
        .alert-success { background-color: #e8f5e9; color: #2e7d32; border: 1px solid #a5d6a7; padding: 12px; border-radius: 4px; margin-bottom: 20px; text-align: center; font-size: 14px; }
        
        .link-rodape { text-align: center; margin-top: 20px; font-size: 14px; color: #555; }
        .link-rodape a { color: #FFC107; font-weight: bold; text-decoration: none; }
        .link-rodape a:hover { text-decoration: underline; }
    </style>
</head>
<body>

    <nav class="navbar">
        <div class="nav-logo">FINANÇAS</div>
        <div class="nav-links">
            <a href="#">Início</a>
            <a href="#">Funcionalidades</a>
        </div>
        <div class="nav-profile">👤</div>
    </nav>

    <div class="container">
        <div class="form-box">
            <h2>Aceder à Conta</h2>
            
            <% if (request.getAttribute("mensagemErro") != null) { %>
                <div class="alert-error"><%= request.getAttribute("mensagemErro") %></div>
            <% } %>
            <% if (request.getParameter("sucesso") != null) { %>
                <div class="alert-success">Conta criada com sucesso! Faça login.</div>
            <% } %>

            <form action="UsuarioController" method="POST">
                <div class="form-group">
                    <label>E-mail</label>
                    <input type="email" name="email" required placeholder="O seu e-mail">
                </div>
                <div class="form-group">
                    <label>Palavra-passe</label>
                    <input type="password" name="senha" required placeholder="A sua palavra-passe">
                </div>
                <button type="submit" class="btn-green">Entrar</button>
            </form>

            <div class="link-rodape">
                Ainda não tem conta? <a href="cadastro.jsp">Criar uma agora</a>
            </div>
        </div>
    </div>

</body>
</html>